class Node:

    def __init__(self, x, y):
        self.x = x
        self.y = y
